import { useState } from 'react'
import './App.css'
import Exemplos from './Components/Exemplos'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <section id="center">
    <h1>Segundo App</h1>
    <Exemplos/>


      
    </section>
    </>
  )
}

export default App
